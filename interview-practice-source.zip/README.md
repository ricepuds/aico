# 면접 준비실

기존 [충북교육청 면접후기 사례집](https://interview-cases-xi.vercel.app/)의 공개 질문 데이터를 활용해 새로 만든 Next.js · TypeScript 프로젝트입니다. 원본 소스가 제공되지 않아 기존 저장소의 패치가 아닌 **독립 실행 가능한 새 프로젝트**로 구성했습니다. 운영 사이트에는 아직 배포하지 않았습니다.

## 구현한 기능

- 대학·학과 이름 자동완성 및 부분 검색, 학년도 다중 선택, 권역·계열·자료 면접유형 필터
- 후기 카드, 질문/답변 구분 상세 보기, 페이지 이동, 검색 결과 전체 선택, 선택 후기 인쇄
- 대학·학과를 정확히 선택하면 AI 모의면접 카드 활성화
- 기본 면접 / 전공 심화 면접 / 압박 면접
- 현재 필터를 통과한 해당 대학·학과의 **모든 후기**에서 질문 추출. 현재 페이지나 인쇄 선택과 무관
- 공백 차이를 제거한 동일 질문 중복 제외, 질문 수와 선택 대학·학과 표시
- 질문별 대학·학과·학년도 출처를 포함한 한국어 프롬프트 생성
- 프롬프트 미리보기, 전체 선택, 프롬프트 복사, ChatGPT 연결
- 복사 성공 안내, 복사 권한 거절 시 수동 복사, 팝업 차단 시 직접 열기 링크
- 모바일 대응, 키보드 접근, Escape로 대화상자 닫기, 인쇄 전용 스타일

**OpenAI API 호출, API Key, AI SDK, 서버 AI 생성 기능은 전혀 없습니다.** 프롬프트는 브라우저에서 문자열로 생성되고 클립보드로만 복사됩니다. ChatGPT URL에 프롬프트를 넣지 않습니다. 사용자가 자신의 계정에서 직접 붙여넣어 전송합니다.

## 실행

Node.js 22.18 이상을 설치한 뒤, 이 README가 있는 프로젝트 폴더에서 실행합니다.

```powershell
npm ci
npm run dev
```

브라우저에서 <http://127.0.0.1:3000>을 엽니다. 실행에 필요한 환경변수는 없습니다.

실제 저장된 데이터로 확인하려면 다음을 선택하세요.

- 대학: **가천대학교**
- 학과: **컴퓨터공학전공** (예시의 ‘컴퓨터공학과’와 저장된 명칭이 다릅니다.)
- 학년도: **전체** 또는 **2023**
- 결과: 후기 **1건**, 중복 제외 질문 **7개** — 임의의 예시 수치 37개를 사용하지 않습니다.

시작 버튼을 누른 뒤, 복사된 내용을 ChatGPT 입력창에 붙여넣고 직접 전송하세요. ‘면접 종료’라고 말하면 최종 피드백을 요청하도록 프롬프트가 구성되어 있습니다.

## 파일과 주요 코드

| 파일 | 내용 |
| --- | --- |
| `src/app/page.tsx` | 자료 로딩, 검색·필터·선택 상태, 후기 목록, 페이지 이동, 인쇄 연결 |
| `src/components/mock-interview.tsx` | AI 카드, 면접 유형, 프롬프트 미리보기, 복사·ChatGPT 열기·실패 안내 |
| `src/lib/interview.ts` | 데이터 타입, 필터, 질문/답변 파서, 중복 제거, 유형별 프롬프트 생성 |
| `src/lib/clipboard.ts` | Clipboard API 및 구형 브라우저 복사 대체 처리 |
| `src/components/case-content.tsx` | 후기 본문과 인쇄용 질문/답변 표현 |
| `src/components/modal.tsx` | 접근 가능한 네이티브 dialog 공통 컴포넌트 |
| `src/app/globals.css` | 데스크톱·모바일·인쇄 스타일 |
| `src/app/layout.tsx`, `src/app/icon.svg` | 한국어 메타데이터, 아이콘 |
| `public/data/cases.json` | 원본의 필드 구조를 유지한 후기 1,878건 스냅샷 |
| `public/data/source.json` | 원본 주소, 수집 시각, 저작권 문구 |
| `scripts/sync-data.mjs` | 원본 데이터 다운로드, 구조·ID 검증, 스냅샷 갱신 |
| `tests/interview.test.ts` | 필터·질문 파서·프롬프트 단위 테스트 |
| `tests/e2e/interview.spec.ts`, `playwright.config.ts` | 브라우저 흐름 검증 |
| `package.json`, `package-lock.json`, `tsconfig.json` | 의존성, 실행 명령, strict TypeScript 설정 |

### 데이터 흐름

```text
public/data/cases.json
  → filterCases (기존 조건과 같은 공백 무시 부분 검색)
  → 정확한 대학·학과 일치 결과
  → parseContent (질문/답변/안내 구분)
  → extractQuestions (질문만 추출·중복 제거·출처 보존)
  → buildPrompt (선택 면접 유형 및 진행 규칙 반영)
  → 클립보드 복사 → ChatGPT 새 탭 → 사용자가 붙여넣어 전송
```

기존 운영 화면의 공개된 검색 및 질문 파서 규칙을 참고해 TypeScript로 재구현했습니다. 후기 내용과 데이터 필드(`id`, `year`, `volume`, `uni`, `dept`, `type`, `name`, `region`, `field`, `interview`, `content`)는 그대로 보존했습니다. 학생의 기존 답변을 프롬프트에 넣지 않으며, 참고 질문 속 활동을 현재 사용자가 했다고 단정하지 않도록 지시합니다.

팝업 차단을 줄이기 위해 클릭 순간에 복사를 시작하고 빈 탭을 확보합니다. 복사에 성공한 뒤에만 해당 탭을 ChatGPT로 이동하고 실패하면 닫습니다. `opener`는 제거합니다. 탭을 열 수 없는 환경에서도 복사 성공 안내와 직접 열기 링크를 제공합니다.

대학·학과 명칭이 일부만 입력된 동안에는 후기는 검색되지만, 다른 학과의 질문이 섞이지 않도록 AI 시작 버튼은 비활성화됩니다. 필터를 바꾸면 이전 선택 상태의 성공 안내와 미리보기가 초기화됩니다. 프롬프트를 임의로 자르지 않으며, 너무 길면 학년도 필터로 범위를 좁힐 수 있습니다.

## 데이터 갱신

실행 중인 앱은 이 프로젝트의 정적 스냅샷만 읽습니다. 원본 사이트에 계속 의존하지 않으며 자동 동기화하지 않습니다. 최신 자료로 갱신하려면 다음을 실행하고 다시 빌드·배포하세요.

```powershell
npm run data:sync
```

원본이 로그인을 요구하거나 응답 구조가 변경되면 갱신은 실패하고 기존 질문 파일을 유지합니다. 인증을 우회하는 로직은 없습니다. 데이터가 바뀌면 실데이터 기준 테스트의 예상 건수도 함께 검토하세요.

## 테스트

```powershell
npm test
npm run typecheck
npm run build
npx playwright install chromium
npm run test:e2e
```

브라우저 테스트는 빌드 후 로컬 프로덕션 서버를 자동으로 시작합니다. 이미 3000번 포트에서 이 프로젝트가 실행 중이면 그 서버를 사용합니다. 다른 앱이 해당 포트를 사용하는 경우 종료하거나 테스트 설정을 바꾸세요.

설치된 Chrome을 사용할 경우 PowerShell에서 다음처럼 실행할 수 있습니다.

```powershell
$env:PLAYWRIGHT_EXECUTABLE_PATH = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
npm run test:e2e
```

검증 범위: 실제 클립보드 내용과 미리보기의 일치, ChatGPT 대상 URL과 opener 제거, 복사 거절, 팝업 차단, 수동 선택, 질문 없음, 세 가지 프롬프트, 전체 검색 결과 사용, 후기 조회·인쇄 스타일·페이지 이동, 모바일 가로 넘침, 데이터 로딩 실패·재시도.

자동 테스트에서는 ChatGPT의 외부 응답을 대체하여 로그인·봇 검사에 의존하지 않고 대상 URL을 검증합니다. 실제 ChatGPT 계정 로그인이나 답변 생성은 자동으로 수행하지 않습니다. Chromium에서 확인했으며 iOS Safari의 클립보드 권한과 팝업 정책은 배포 미리보기에서 별도 확인하세요.

## Vercel 배포 전 확인

1. `npm test`, `npm run typecheck`, `npm run build`가 성공하는지 확인합니다.
2. 프로젝트 폴더를 Git 저장소에 올리고 Vercel에서 Import 합니다. Framework Preset은 **Next.js**, Node.js는 **22.x 이상**, Build Command는 `npm run build`로 설정합니다. 이 폴더만 올리면 Root Directory는 루트입니다.
3. `public/data/cases.json`과 `source.json`이 포함되어 있는지 확인합니다. `.next`, `node_modules`, 테스트 결과는 올리지 않습니다.
4. **API Key나 OpenAI 관련 환경변수는 추가하지 않습니다.** 필요한 환경변수는 없습니다.
5. Preview Deployment의 HTTPS 주소에서 대학·학과 선택 → 미리보기 → 복사 → ChatGPT 열기 → 붙여넣기를 확인합니다. 팝업 차단 상태와 모바일 Safari도 확인합니다.
6. 데이터 출처·저작권 문구를 유지하고, 운영 자료의 갱신 여부를 확인합니다.
7. 기존 `interview-cases-xi.vercel.app` 주소로 교체하려면 해당 Vercel 프로젝트의 관리 권한이 필요합니다. 새 프로젝트 배포만으로 기존 주소가 변경되지는 않습니다.

원본의 로그인·담당자 문의 전송 서버, 별도로 작성된 대학별 분석 콘텐츠는 원본 소스가 없어 복제하지 않았습니다. 담당자 문의는 기존 자료실로 연결합니다. 새 프로젝트는 검색·필터·후기 상세·인쇄·AI 모의면접 흐름을 구현한 것으로, 기존 서버와 연결된 모든 기능을 그대로 이전한 것은 아닙니다.
